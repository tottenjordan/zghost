brief_data_extraction_instructions = """
Extract the details from the sample marketing brief. 
Be sure to use the schema provided to generate the most detailed summary of the brief.
Use this tool when the user initially provides a pdf or document that shows brand strategy.

This data will be used downstream to create ideas for marketing campaigns.
"""